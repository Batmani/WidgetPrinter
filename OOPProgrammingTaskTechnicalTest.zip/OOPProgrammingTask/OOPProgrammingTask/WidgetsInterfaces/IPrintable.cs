﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OOPProgrammingTask.WidgetsInterfaces
{
    public interface IPrintable
    {
        string GetWidgetName();
        string GetWidgetValues();
    }
}
